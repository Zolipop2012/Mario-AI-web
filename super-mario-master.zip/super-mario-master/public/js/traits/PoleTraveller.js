import { Vec2 } from '../math.js';
import Trait from '../Trait.js';

export default class PoleTraveller extends Trait {
    constructor() {
        super();
        this.distance = 0;
    }
}
